#include <iostream>

using std::cout;
using std::endl;

void pass_by_value(int n);
void pass_by_reference(int &n);
void pass_by_pointer(int *n);

int main() {
    int n = 100;
    cout << "= = = = = = = = = = = = = = = = =" << endl;
    cout << "integer n: " << n << endl;
    cout << "address of n in main: " << &n << endl;

    pass_by_value(n);
    pass_by_reference(n);
    pass_by_pointer(&n);

    return 0;
}


void pass_by_value(int n) {
    cout << "= = = = = = = = = = = = = = = = =" << endl;
    cout << "pass by value" << endl;
    cout << "value of n: " << n << endl;
    cout << "address of n: " << &n << endl;
}

void pass_by_reference(int &n) {
    cout << "= = = = = = = = = = = = = = = = =" << endl;
    cout << "pass by reference" << endl;
    cout << "value of n: " << n << endl;
    cout << "address of n: " << &n << endl;
}

void pass_by_pointer(int *n) {
    cout << "= = = = = = = = = = = = = = = = =" << endl;
    cout << "pass by reference" << endl;
    cout << "value of n: " << *n << endl;
    cout << "address of n: " << n << endl;
}
