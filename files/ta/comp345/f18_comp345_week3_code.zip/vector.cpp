#include <iostream>
#include <vector>

using std::vector;
using std::cout;
using std::endl;


int main() {
    
    vector<int> vecInt;

    // add elements into the vector
    for (int i = 0; i < 10; i++) {
        vecInt.push_back(i);
    }

    // traverse the vector
    for (auto it = vecInt.begin(); it != vecInt.end(); it++) {
        cout << it.operator*() << " ";
    }
    cout << endl;

    // another way to traverse
    for (auto &vec : vecInt) {
        cout << vec << " ";
    }
    cout << endl;

    // access via index
    cout << "the 2nd element in the vector is -> " << vecInt[1] << endl;

    // access the first and last element
    cout << "the 1st element in the vector is -> " << vecInt.front() << endl;
    cout << "the last element in the vector is -> " << vecInt.back() << endl;

    // ...... try to discover more APIs by yourself

    return 0;
}