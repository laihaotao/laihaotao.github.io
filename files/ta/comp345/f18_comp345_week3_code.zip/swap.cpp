#include <iostream>

using std::cout;
using std::endl;

void swap1(int x, int y);
void swap2(int &x, int &y);
void swap3(int *x, int *y);

int main(int argc, char const *argv[]) {
    int i = 10;
    int j = 20;

    cout << "- - - - Before - - - -" << endl;
    cout << "value of i: " << i << endl;
    cout << "value of j: " << j << endl;

    // /////
    swap1(i, j);
    cout << "--- After calling swap(int x, int y) ---" << endl;
    cout << "value of i: " << i << endl;
    cout << "value of j: " << j << endl;

    // /////
    swap2(i, j);
    cout << "--- After calling swap(int &x, int &y) ---" << endl;
    cout << "value of i: " << i << endl;
    cout << "value of j: " << j << endl;
    
    // /////
    swap3(&i, &j);
    cout << "--- After calling swap(int *x, int *y) ---" << endl;
    cout << "value of i: " << i << endl;
    cout << "value of j: " << j << endl;
    return 0;
}

void swap1(int x, int y) {
    int tmp = x;
    x = y;
    y = tmp;
}

void swap2(int &x, int &y) {
    int tmp = x;
    x = y;
    y = tmp;
}

void swap3(int *x, int *y) {
    int tmp = *x;
    *x = *y;
    *y = tmp;
}

void badExampleWithPointer(int *x, int *y) {
    int *tmp = x;
    x = y;
    y = tmp;
}