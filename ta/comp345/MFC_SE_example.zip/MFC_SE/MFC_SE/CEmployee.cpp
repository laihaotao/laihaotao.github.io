#include "stdafx.h"
#include "CEmployee.h"

IMPLEMENT_SERIAL(CEmployee, CObject, 1)

CEmployee::CEmployee()
{
}

CEmployee::CEmployee(int id, CString name): id(id), name(name)
{
}


CEmployee::~CEmployee()
{
}

void CEmployee::Serialize(CArchive& ar)
{
	// you have to call the parent's method
	CObject::Serialize(ar);

	if (ar.IsStoring())
	{
		// if you want to store something
		ar << id << name;
	}
	else
	{
		// otherwise you want to read something
		ar >> id >> name;
	}
}
