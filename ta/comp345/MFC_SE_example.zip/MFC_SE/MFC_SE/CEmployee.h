#pragma once
#include "afx.h"

class CEmployee :
	public CObject
{
public:
	int id;
	CString name;

	CEmployee();
	CEmployee(int id, CString name);
	~CEmployee();

	// have to implement this method
	virtual void Serialize(CArchive &ar);
	
	DECLARE_SERIAL(CEmployee)
};

