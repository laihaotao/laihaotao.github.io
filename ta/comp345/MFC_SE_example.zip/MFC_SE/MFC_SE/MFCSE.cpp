// MFCSE.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "CEmployee.h"
#include <iostream>
#include <CString>

using namespace std;

void save_object()
{
	cout << "start to write object into file ..." << endl;
	// prepare the environment
	CFile file;
	file.Open(_T("CArchive__Test.txt"), CFile::modeCreate | CFile::modeWrite);
	CArchive ar(&file, CArchive::store);
	
	// create a testing object
	CEmployee employee(112, "Eric");
	cout << "Employee id: " << employee.id << endl;
	wcout << "Employee name: " << employee.name.GetString() << endl;

	// call the method you implement
	employee.Serialize(ar);

	ar.Close();

	cout << "finish saving object ..." << endl;
}

void load_object()
{
	cout << "start to read object from file ..." << endl;

	// prepare the environment
	CFile file;
	file.Open(_T("CArchive__Test.txt"), CFile::modeRead);
	CArchive ar(&file, CArchive::load);
	CEmployee employee;

	// call the method you implement
	employee.Serialize(ar);

	ar.Close();
	file.Close();

	cout << "Employee id: " << employee.id << endl;
	wcout << "Employee name: " << employee.name.GetString() << endl;

	cout << "finish loading object ..." << endl;
}

int main()
{
	save_object();
	load_object();
	system("pause");
    return 0;
}

