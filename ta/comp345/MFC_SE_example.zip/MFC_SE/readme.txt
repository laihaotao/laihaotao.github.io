There are only three file you need to read is the following:

1. CEmployee.cpp
2. CEmployee.h
3. MFC_SE.cpp (main function)

I created that project in VS 2017, if you have that you should be able to run it directly.

Eric