// COMP 345
// Create by Haotao Lai (Eric)
// h_lai@encs.concordia.ca

#include <iostream>

using namespace std;

class Base
{
public:
	void f1(){ cout << "f1 inside Base" << endl; };
	virtual void f2(){ cout << "f2 inside Base" << endl; };
};

class Derived : public Base
{
public:
	void f1(){ cout << "f1 inside Derived" << endl; };
	virtual void f2(){ cout << "f2 inside Derived" << endl; };
};

void example1();
void example2();

int main()
{
	example1();
	example2();
	return 0;
}

void example1() {
	cout << "======== example 1 =======" << endl;
	// declare a subclass of Base
	Derived drived;
	
	// use a super class pointer point to its subclass instance
	Base *ptrBase = &drived;
	
	// f1 is not a virtual method, the following code will call f1 in the Base class
	ptrBase->f1();
	// f2 is a virtual method, the following code will call the f2 inside Derived class
	ptrBase->f2();
	cout << "==== end of example 1 ====" << endl;
}

void example2() {
	cout << "======== example 2 =======" << endl;
	
	// use a super class pointer point to its subclass instance
	Base* ptrBase = new Derived();
	
	// f1 is not a virtual method, the following code will call f1 in the Base class
	ptrBase->f1();
	// f2 is a virtual method, the following code will call the f2 inside Derived class
	ptrBase->f2();
	
	delete ptrBase;
	
	cout << "==== end of example 2 ====" << endl;
}
