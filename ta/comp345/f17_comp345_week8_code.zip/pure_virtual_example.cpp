// COMP 345
// Create by Haotao Lai (Eric)
// h_lai@encs.concordia.ca

#include <iostream>

using namespace std;

class Animal
{
public:
	Animal(std::string name): name(name) {};
	std::string name;
	
	// declare an pure virtual method
	// attention the syntax here, different from the virtual method
	virtual void say_hello() = 0;
};

class Dog : public Animal
{
public:
	Dog(std::string name): Animal(name) {};
	virtual void say_hello() { cout << "Hello, I am a dog, my name is: " << this->name << endl; };
};

int main()
{
	// You cannot create an animal instance, the following line is incorrect
	//  -> error: cannot declare variable ‘animal’ to be of abstract type ‘Animal’
//	 Animal animal("DDDog");
	
	Animal *ptrAnimal;
	Dog dog("DDDog");
	
	ptrAnimal = &dog;
	ptrAnimal->say_hello();
	
	return 0;
}