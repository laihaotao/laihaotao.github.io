#include <iostream>

using namespace std;


class Animal
{
public:
	Animal(std::string name): name(name) {};
	std::string name;
	
	void say_hello() { cout << "say hello from Animal ..." << endl; };
};

class AkindDog : public Animal
{
public:
	AkindDog(std::string name): Animal(name) {};
	void another_say_hello() { cout << "Hello, I am AkindDog ..." << endl; };
};

class BkindDog : public Animal
{
public:
	BkindDog(std::string name): Animal(name) {};
	void another_say_hello() { cout << "Hello, I am BkindDog ..." << endl; };
};

class AB_Hybrid_kindDog : public AkindDog, BkindDog
{
public:
//	AB_Hybrid_kindDog(std::string name): Animal(name), AkindDog(name), BkindDog(name) {};
  	AB_Hybrid_kindDog(std::string name): AkindDog(name), BkindDog(name) {};
};

int main()
{
	Animal *ptrAnimal = new AB_Hybrid_kindDog("dddog");
	ptrAnimal->say_hello();
}


/*

out put when I try to compile the code

$ g++ -o wrong_version_virtual_inheritance wrong_version_virtual_inheritance.cpp
wrong_version_virtual_inheritance.cpp: In function ‘int main()’:
wrong_version_virtual_inheritance.cpp:38:51: error: ‘Animal’ is an ambiguous base of ‘AB_Hybrid_kindDog’
  Animal *ptrAnimal = new AB_Hybrid_kindDog("dddog");

*/