#include <iostream>

using namespace std;


class Animal
{
public:
	Animal(std::string name): name(name) {};
	std::string name;
	
	void say_hello() { cout << "say hello from Animal ..." << endl; };
};

class AkindDog : virtual public Animal
{
public:
	AkindDog(std::string name): Animal(name) {};
	void another_say_hello() { cout << "Hello, I am AkindDog ..." << endl; };
};

class BkindDog : virtual public Animal
{
public:
	BkindDog(std::string name): Animal(name) {};
	void another_say_hello() { cout << "Hello, I am BkindDog ..." << endl; };
};

class AB_Hybrid_kindDog : public AkindDog, BkindDog
{
public:
	AB_Hybrid_kindDog(std::string name): Animal(name), AkindDog(name), BkindDog(name) {};
};

int main()
{
	Animal *ptrAnimal = new AB_Hybrid_kindDog("dddog");
	ptrAnimal->say_hello();
}